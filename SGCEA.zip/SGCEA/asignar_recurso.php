<?php
// asignar_recurso.php (RF-08 / RF-09)
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (!in_array($_SESSION['rol'] ?? '', ['Administrador', 'Tecnico'])) {
    echo json_encode(["success" => false, "message" => "No tiene permiso para asignar recursos."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id_evento = intval($data['id_evento'] ?? 0);
$id_recurso = intval($data['id_recurso'] ?? 0);
$fecha = $data['fecha'] ?? '';

if (!$id_evento || !$id_recurso || empty($fecha)) {
    echo json_encode(["success" => false, "message" => "Faltan datos obligatorios."]);
    exit;
}

$stmt = $conexion->prepare("INSERT INTO asignacion_recursos (id_evento, id_recurso, fecha) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $id_evento, $id_recurso, $fecha);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Recursos asignados correctamente."]);
} else {
    echo json_encode(["success" => false, "message" => "El recurso seleccionado ya está ocupado en esa fecha."]);
}
?>