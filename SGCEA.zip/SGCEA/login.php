<?php
session_start();
require_once "conexion.php";

$error = "";

function verificarPassword($passwordIngresada, $passwordAlmacenada) {
    $passwordAlmacenada = trim($passwordAlmacenada);

    // 1) Hash generado con password_hash() de PHP (bcrypt/argon2: $2y$, $argon2i$, etc.)
    if (preg_match('/^\$2y\$|^\$argon2/', $passwordAlmacenada)) {
        return password_verify($passwordIngresada, $passwordAlmacenada);
    }

    // 2) Hash MD5 de 32 caracteres (típico al insertar el usuario desde phpMyAdmin)
    if (preg_match('/^[a-f0-9]{32}$/i', $passwordAlmacenada)) {
        return strtolower(md5($passwordIngresada)) === strtolower($passwordAlmacenada);
    }

    // 3) Contraseña guardada en texto plano
    return $passwordIngresada === $passwordAlmacenada;
}

// Si ya hay sesión activa, redirigir al panel principal
if (isset($_SESSION['id_usuario'])) {
    header("Location: panel.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $rol_seleccionado = $_POST['rol'] ?? 'Administrador';

    if (!empty($email) && !empty($password)) {
        // Consultar únicamente por email para evitar problemas de concordancia de rol
        $stmt = $conexion->prepare("SELECT id_usuario, nombre, password, rol, id_cliente FROM usuarios WHERE email = ?");

        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($user = $result->fetch_assoc()) {
                // Validación del rol seleccionado con el registrado en la base de datos
                if ($user['rol'] !== $rol_seleccionado) {
                    $error = "El rol seleccionado no corresponde a esta cuenta.";
                }
                // Verificar la contraseña. Se admiten tres formatos, porque en
                // phpMyAdmin es común insertar el usuario con la función MD5(),
                // no solo con password_hash() de PHP ni en texto plano:
                //  1) Hash de password_hash()  -> password_verify()
                //  2) Hash MD5 (32 caracteres)  -> md5($password)
                //  3) Texto plano               -> comparación directa
                elseif (verificarPassword($password, $user['password'])) {

                    // Asignación de variables de sesión
                    $_SESSION['id_usuario'] = $user['id_usuario'];
                    $_SESSION['nombre'] = $user['nombre'];
                    $_SESSION['rol'] = $user['rol'];
                    $_SESSION['id_cliente'] = $user['id_cliente'];

                    // Redirección
                    header("Location: panel.php");
                    exit;
                } else {
                    $error = "Contraseña incorrecta.";
                }
            } else {
                $error = "El correo electrónico no se encuentra registrado.";
            }
            $stmt->close();
        } else {
            $error = "Error al preparar la consulta: " . $conexion->error;
        }
    } else {
        $error = "Por favor completa todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - SGCEA</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

<header>
    <a href="index.html" class="logo">Quinto Canal de Eventos</a>
    <nav>
        <a href="index.html">Inicio</a>
    </nav>
</header>

<div class="auth-box">
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($error)): ?>
        <div class="alert-danger" style="text-align: center;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <div class="form-group">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required placeholder="admin@quintocanal.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required placeholder="********">
        </div>

        <div class="form-group">
            <label for="rol">Rol de Acceso:</label>
            <select id="rol" name="rol" required>
                <option value="Administrador" <?= (isset($_POST['rol']) && $_POST['rol'] === 'Administrador') ? 'selected' : '' ?>>Administrador</option>
                <option value="Tecnico" <?= (isset($_POST['rol']) && $_POST['rol'] === 'Tecnico') ? 'selected' : '' ?>>Técnico</option>
                <option value="Cliente" <?= (isset($_POST['rol']) && $_POST['rol'] === 'Cliente') ? 'selected' : '' ?>>Cliente</option>
            </select>
        </div>

        <button type="submit" class="btn">Ingresar al Sistema</button>
    </form>

    <p style="text-align:center; margin-top:1rem;">
        ¿Aún no tienes cuenta? <a href="registro.php">Regístrate aquí</a>
    </p>
</div>

</body>
</html>
