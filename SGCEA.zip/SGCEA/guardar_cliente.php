<?php
// guardar_cliente.php (RF-01)
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (($_SESSION['rol'] ?? '') !== 'Administrador') {
    echo json_encode(["success" => false, "message" => "Solo el administrador puede gestionar clientes."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$id_cliente = $data['id_cliente'] ?? null;
$nombre = trim($data['nombre'] ?? '');
$contacto = trim($data['contacto'] ?? '');
$direccion = trim($data['direccion'] ?? '');
$datos_fiscales = trim($data['datos_fiscales'] ?? '');

if (empty($nombre) || empty($contacto) || empty($direccion) || empty($datos_fiscales)) {
    echo json_encode(["success" => false, "message" => "Todos los campos del cliente son obligatorios."]);
    exit;
}

if ($id_cliente) {
    // Actualizar cliente
    $stmt = $conexion->prepare("UPDATE clientes SET nombre = ?, contacto = ?, direccion = ?, datos_fiscales = ? WHERE id_cliente = ?");
    $stmt->bind_param("ssssi", $nombre, $contacto, $direccion, $datos_fiscales, $id_cliente);
    $accion = "actualizado";
} else {
    // Registrar nuevo cliente
    $stmt = $conexion->prepare("INSERT INTO clientes (nombre, contacto, direccion, datos_fiscales) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $contacto, $direccion, $datos_fiscales);
    $accion = "registrado";
}

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Cliente $accion correctamente."]);
} else {
    echo json_encode(["success" => false, "message" => "Error al procesar cliente: " . $conexion->error]);
}
?>
