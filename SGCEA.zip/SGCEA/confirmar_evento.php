<?php
// confirmar_evento.php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (!in_array($_SESSION['rol'] ?? '', ['Administrador', 'Tecnico'])) {
    echo json_encode(["success" => false, "message" => "No tiene permiso para confirmar eventos."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id_evento = $data['id_evento'] ?? null;

if (!$id_evento) {
    echo json_encode(["success" => false, "message" => "Seleccione un evento válido."]);
    exit;
}

// Consultar monto total y anticipo pagado
$query = "SELECT c.monto_total, 
                 COALESCE(SUM(p.monto), 0) AS total_anticipo
          FROM eventos e
          JOIN contratos ct ON e.id_contrato = ct.id_contrato
          JOIN cotizaciones c ON ct.id_cotizacion = c.id_cotizacion
          LEFT JOIN pagos p ON e.id_evento = p.id_evento AND p.tipo = 'Anticipo 50%'
          WHERE e.id_evento = ?";

$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_evento);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();

$monto_total = floatval($res['monto_total'] ?? 0);
$total_anticipo = floatval($res['total_anticipo'] ?? 0);
$anticipo_requerido = $monto_total * 0.50;

if ($total_anticipo < $anticipo_requerido) {
    echo json_encode([
        "success" => false, 
        "message" => "No se puede confirmar el evento. Se requiere un anticipo de al menos el 50% ($" . number_format($anticipo_requerido, 2) . ")."
    ]);
    exit;
}

// Actualizar estado a Confirmado
$update = $conexion->prepare("UPDATE eventos SET estado = 'Confirmado' WHERE id_evento = ?");
$update->bind_param("i", $id_evento);

if ($update->execute()) {
    echo json_encode(["success" => true, "message" => "Evento confirmado correctamente con anticipo del 50% validado."]);
} else {
    echo json_encode(["success" => false, "message" => "Error al actualizar el estado del evento."]);
}
?>