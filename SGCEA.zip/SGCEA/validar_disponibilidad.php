<?php
// validar_disponibilidad.php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(["success" => false, "message" => "Debe iniciar sesión."]);
    exit;
}

$fecha = $_GET['fecha'] ?? '';

if (empty($fecha)) {
    echo json_encode(["success" => false, "message" => "Proporcione una fecha válida."]);
    exit;
}

$query = "SELECT r.id_recurso, r.nombre, r.tipo,
                 IF(ar.id_asignacion IS NOT NULL, 'Ocupado', 'Disponible') AS estado_disponibilidad
          FROM recursos r
          LEFT JOIN asignacion_recursos ar ON r.id_recurso = ar.id_recurso AND ar.fecha = ?
          ORDER BY r.tipo, r.nombre";

$stmt = $conexion->prepare($query);
$stmt->bind_param("s", $fecha);
$stmt->execute();
$result = $stmt->get_result();

$recursos = [];
while ($row = $result->fetch_assoc()) {
    $recursos[] = $row;
}

echo json_encode(["success" => true, "fecha" => $fecha, "recursos" => $recursos]);
?>