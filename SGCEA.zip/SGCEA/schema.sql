-- =====================================================================
-- SGCEA - Sistema de Gestión de Cotizaciones y Eventos Audiovisuales
-- Esquema de base de datos (faltaba en el proyecto original)
-- Importar en phpMyAdmin / MySQL antes de usar el sistema.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS sgcea_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sgcea_db;

-- Clientes (RD-01)
CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    contacto VARCHAR(150) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    datos_fiscales VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Usuarios del sistema (RF-10: acceso diferenciado por rol)
CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('Administrador','Tecnico','Cliente') NOT NULL,
    id_cliente INT NULL, -- solo se usa cuando rol = 'Cliente', enlaza con clientes.id_cliente
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Cotizaciones (RD-02)
CREATE TABLE cotizaciones (
    id_cotizacion INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    nombre_evento VARCHAR(150) NOT NULL,
    descripcion_tecnica TEXT NOT NULL,
    monto_total DECIMAL(10,2) NOT NULL,
    vigencia DATE NOT NULL,
    estado ENUM('Pendiente','Aprobada','Rechazada','Vencida') NOT NULL DEFAULT 'Pendiente',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Servicios audiovisuales incluidos en cada cotización (RD-06)
CREATE TABLE cotizacion_servicios (
    id_servicio INT AUTO_INCREMENT PRIMARY KEY,
    id_cotizacion INT NOT NULL,
    servicio VARCHAR(60) NOT NULL,
    FOREIGN KEY (id_cotizacion) REFERENCES cotizaciones(id_cotizacion) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Contratos (RD-03)
CREATE TABLE contratos (
    id_contrato INT AUTO_INCREMENT PRIMARY KEY,
    id_cotizacion INT NOT NULL UNIQUE,
    fecha_evento DATE NOT NULL,
    ubicacion VARCHAR(255) NOT NULL,
    condiciones TEXT NOT NULL,
    estatus ENUM('Activo','Cancelado') NOT NULL DEFAULT 'Activo',
    FOREIGN KEY (id_cotizacion) REFERENCES cotizaciones(id_cotizacion) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Eventos (RD-04)
CREATE TABLE eventos (
    id_evento INT AUTO_INCREMENT PRIMARY KEY,
    id_contrato INT NOT NULL,
    fecha DATE NOT NULL,
    horario TIME NOT NULL,
    ubicacion VARCHAR(255) NOT NULL,
    tipo_evento VARCHAR(60) NOT NULL,
    estado ENUM('Programado','Confirmado','Reprogramado','Cancelado','Finalizado') NOT NULL DEFAULT 'Programado',
    FOREIGN KEY (id_contrato) REFERENCES contratos(id_contrato) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Pagos (RD-05)
CREATE TABLE pagos (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_evento INT NOT NULL,
    monto DECIMAL(10,2) NOT NULL,
    tipo VARCHAR(30) NOT NULL,       -- 'Anticipo 50%' o 'Pago Final'
    metodo VARCHAR(30) NOT NULL,     -- 'Efectivo', 'Transferencia', 'Tarjeta'
    referencia VARCHAR(100),
    fecha DATE NOT NULL,
    estatus VARCHAR(20) NOT NULL DEFAULT 'Pagado',
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Recursos audiovisuales y personal (RD-06)
CREATE TABLE recursos (
    id_recurso INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    tipo ENUM('Audio','Iluminación','Video','Personal','Transporte') NOT NULL
) ENGINE=InnoDB;

-- Asignación de recursos a eventos (RD-07). El UNIQUE evita que RF-09
-- (validar disponibilidad) permita comprometer el mismo recurso dos veces
-- en la misma fecha.
CREATE TABLE asignacion_recursos (
    id_asignacion INT AUTO_INCREMENT PRIMARY KEY,
    id_evento INT NOT NULL,
    id_recurso INT NOT NULL,
    fecha DATE NOT NULL,
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento) ON DELETE CASCADE,
    FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso) ON DELETE CASCADE,
    UNIQUE KEY recurso_fecha_unico (id_recurso, fecha)
) ENGINE=InnoDB;

-- Historial de eventos finalizados (RD-08)
CREATE TABLE historial_eventos (
    id_historial INT AUTO_INCREMENT PRIMARY KEY,
    id_evento INT NOT NULL UNIQUE,
    servicios_brindados TEXT NOT NULL,
    resultado VARCHAR(255) NOT NULL,
    seguimiento_cliente TEXT,
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- Datos de ejemplo para poder iniciar sesión y probar el sistema
-- =====================================================================

INSERT INTO clientes (nombre, contacto, direccion, datos_fiscales) VALUES
('Grupo Empresarial Orizaba', '272-123-4567', 'Av. Poniente 5, Orizaba, Ver.', 'GEO900101ABC');

-- Contraseñas en texto plano solo para pruebas locales; login.php también
-- admite password_hash() si se generan usuarios reales.
INSERT INTO usuarios (nombre, email, password, rol, id_cliente) VALUES
('Administrador General', 'admin@quintocanal.com', 'admin123', 'Administrador', NULL),
('Técnico de Campo', 'tecnico@quintocanal.com', 'tecnico123', 'Tecnico', NULL),
('Cliente Demo', 'cliente@quintocanal.com', 'cliente123', 'Cliente', 1);

INSERT INTO recursos (nombre, tipo) VALUES
('Consola de audio JBL', 'Audio'),
('Set de bocinas línea A', 'Audio'),
('Cabezas móviles LED', 'Iluminación'),
('Pantalla LED 4x3', 'Video'),
('Técnico de audio', 'Personal'),
('Camioneta de transporte', 'Transporte');
