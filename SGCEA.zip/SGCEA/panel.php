<?php
// panel.php: panel principal, protegido por sesión, con acceso diferenciado por rol (RF-10)
session_start();
require_once 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    header('Location: login.php');
    exit;
}

$rol = $_SESSION['rol'];
$nombre = $_SESSION['nombre'];

// --- Datos para los formularios (listas desplegables) ---
$clientes = $conexion->query("SELECT id_cliente, nombre FROM clientes ORDER BY nombre");
$cotizaciones_aprobadas = $conexion->query("SELECT c.id_cotizacion, c.nombre_evento, cl.nombre AS cliente
                                             FROM cotizaciones c
                                             JOIN clientes cl ON c.id_cliente = cl.id_cliente
                                             LEFT JOIN contratos ct ON ct.id_cotizacion = c.id_cotizacion
                                             WHERE c.estado = 'Aprobada' AND ct.id_contrato IS NULL
                                             ORDER BY c.id_cotizacion DESC");
$eventos = $conexion->query("SELECT e.id_evento, e.fecha, e.estado, cl.nombre AS cliente, c.nombre_evento
                              FROM eventos e
                              JOIN contratos ct ON e.id_contrato = ct.id_contrato
                              JOIN cotizaciones c ON ct.id_cotizacion = c.id_cotizacion
                              JOIN clientes cl ON c.id_cliente = cl.id_cliente
                              ORDER BY e.fecha DESC");
$recursos = $conexion->query("SELECT id_recurso, nombre, tipo FROM recursos ORDER BY tipo, nombre");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel - SGCEA</title>
<link rel="stylesheet" href="Styles.css">
</head>
<body>

<header>
    <a href="index.html" class="logo">Quinto Canal de Eventos</a>
    <nav>
        <span id="current-user-text" style="color:#fff; margin-right:1rem;">Usuario: <?= htmlspecialchars($nombre) ?> (<?= htmlspecialchars($rol) ?>)</span>
        <a href="logout.php" class="btn-nav">Cerrar Sesión</a>
    </nav>
</header>

<div class="container">
    <nav class="tabs">
        <?php if ($rol === 'Administrador'): ?>
            <button class="nav-btn" data-target="window-clientes">Clientes</button>
            <button class="nav-btn" data-target="window-cotizaciones">Cotizaciones</button>
            <button class="nav-btn" data-target="window-contratos">Contratos</button>
            <button class="nav-btn" data-target="window-eventos">Eventos</button>
            <button class="nav-btn" data-target="window-pagos">Pagos</button>
            <button class="nav-btn" data-target="window-recursos">Recursos</button>
            <button class="nav-btn" data-target="window-historial">Historial</button>
        <?php elseif ($rol === 'Tecnico'): ?>
            <button class="nav-btn" data-target="window-eventos">Eventos</button>
            <button class="nav-btn" data-target="window-recursos">Recursos</button>
            <button class="nav-btn" data-target="window-historial">Historial</button>
        <?php elseif ($rol === 'Cliente'): ?>
            <button class="nav-btn" data-target="window-cotizaciones">Mis Cotizaciones</button>
            <button class="nav-btn" data-target="window-historial">Mi Historial</button>
        <?php endif; ?>
    </nav>

    <!-- CLIENTES (RF-01) -->
    <?php if ($rol === 'Administrador'): ?>
    <section id="window-clientes" class="window-content hidden">
        <h2>Gestión de Clientes</h2>
        <div class="card" style="padding:1.5rem; margin-bottom:1.5rem;">
            <form id="form-cliente">
                <div class="form-group"><label>Nombre:</label><input type="text" id="cli-nombre" required></div>
                <div class="form-group"><label>Contacto:</label><input type="text" id="cli-contacto" required></div>
                <div class="form-group"><label>Dirección:</label><input type="text" id="cli-direccion" required></div>
                <div class="form-group"><label>Datos fiscales:</label><input type="text" id="cli-fiscales" required></div>
                <button type="submit" class="btn">Registrar Cliente</button>
            </form>
        </div>
    </section>
    <?php endif; ?>

    <!-- COTIZACIONES (RF-02, RF-03) -->
    <section id="window-cotizaciones" class="window-content hidden">
        <h2><?= $rol === 'Cliente' ? 'Mis Cotizaciones' : 'Gestión de Cotizaciones' ?></h2>

        <?php if ($rol === 'Administrador'): ?>
        <div class="card" style="padding:1.5rem; margin-bottom:1.5rem;">
            <h3>Nueva Cotización (RF-02)</h3>
            <form id="form-cotizacion">
                <div class="form-group">
                    <label>Cliente:</label>
                    <select id="cot-cliente" required>
                        <option value="">Seleccione...</option>
                        <?php while ($c = $clientes->fetch_assoc()): ?>
                            <option value="<?= $c['id_cliente'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group"><label>Nombre del evento:</label><input type="text" id="cot-evento" required></div>
                <div class="form-group"><label>Descripción técnica:</label><textarea id="cot-desc" rows="2" required></textarea></div>
                <div class="form-group">
                    <label>Servicios:</label><br>
                    <label><input type="checkbox" name="servicio" value="Audio"> Audio</label>
                    <label><input type="checkbox" name="servicio" value="Iluminación"> Iluminación</label>
                    <label><input type="checkbox" name="servicio" value="Video"> Video</label>
                    <label><input type="checkbox" name="servicio" value="Escenografía"> Escenografía</label>
                </div>
                <div class="form-group"><label>Monto total ($):</label><input type="number" step="0.01" id="cot-monto" required></div>
                <div class="form-group"><label>Vigencia:</label><input type="date" id="cot-vigencia" required></div>
                <button type="submit" class="btn">Guardar Cotización</button>
            </form>
        </div>
        <?php endif; ?>

        <table class="tabla">
            <thead>
                <tr><th>ID</th><th>Cliente</th><th>Evento</th><th>Servicios</th><th>Monto</th><th>Vigencia</th><th>Estado</th><?= $rol === 'Cliente' ? '<th>Acción</th>' : '' ?></tr>
            </thead>
            <tbody id="tabla-cotizaciones-body"></tbody>
        </table>
    </section>

    <!-- CONTRATOS (RF-04) -->
    <?php if ($rol === 'Administrador'): ?>
    <section id="window-contratos" class="window-content hidden">
        <h2>Generar Contrato</h2>
        <div class="card" style="padding:1.5rem;">
            <form id="form-contrato">
                <div class="form-group">
                    <label>Cotización aprobada:</label>
                    <select id="con-cotizacion" required>
                        <option value="">Seleccione...</option>
                        <?php while ($c = $cotizaciones_aprobadas->fetch_assoc()): ?>
                            <option value="<?= $c['id_cotizacion'] ?>">#<?= $c['id_cotizacion'] ?> - <?= htmlspecialchars($c['cliente']) ?> - <?= htmlspecialchars($c['nombre_evento']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group"><label>Fecha del evento:</label><input type="date" id="con-fecha" required></div>
                <div class="form-group"><label>Ubicación:</label><input type="text" id="con-ubicacion" required></div>
                <div class="form-group"><label>Condiciones del servicio:</label><textarea id="con-condiciones" rows="3" required></textarea></div>
                <button type="submit" class="btn">Generar Contrato y Evento</button>
            </form>
        </div>
    </section>
    <?php endif; ?>

    <!-- EVENTOS (RF-05, RF-06, RF-11) -->
    <?php if ($rol === 'Administrador' || $rol === 'Tecnico'): ?>
    <section id="window-eventos" class="window-content hidden">
        <h2>Eventos</h2>
        <table class="tabla">
            <thead><tr><th>ID</th><th>Cliente</th><th>Evento</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr></thead>
            <tbody>
                <?php $eventos->data_seek(0); while ($e = $eventos->fetch_assoc()): ?>
                <tr>
                    <td><?= $e['id_evento'] ?></td>
                    <td><?= htmlspecialchars($e['cliente']) ?></td>
                    <td><?= htmlspecialchars($e['nombre_evento']) ?></td>
                    <td><?= htmlspecialchars($e['fecha']) ?></td>
                    <td><span class="badge badge-<?= strtolower($e['estado']) ?>"><?= $e['estado'] ?></span></td>
                    <td>
                        <?php if ($e['estado'] === 'Programado'): ?>
                            <button class="btn-sm btn-confirmar" data-id="<?= $e['id_evento'] ?>">Confirmar</button>
                        <?php elseif ($e['estado'] === 'Confirmado'): ?>
                            <button class="btn-sm btn-finalizar" data-id="<?= $e['id_evento'] ?>">Finalizar</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>
    <?php endif; ?>

    <!-- PAGOS (RF-07) -->
    <?php if ($rol === 'Administrador'): ?>
    <section id="window-pagos" class="window-content hidden">
        <h2>Registrar Pago</h2>
        <div class="card" style="padding:1.5rem;">
            <form id="form-pago">
                <div class="form-group">
                    <label>Evento:</label>
                    <select id="pago-evento" required>
                        <option value="">Seleccione...</option>
                        <?php $eventos->data_seek(0); while ($e = $eventos->fetch_assoc()): ?>
                            <option value="<?= $e['id_evento'] ?>">#<?= $e['id_evento'] ?> - <?= htmlspecialchars($e['cliente']) ?> - <?= htmlspecialchars($e['fecha']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tipo de pago:</label>
                    <select id="pago-tipo" required>
                        <option value="Anticipo 50%">Anticipo 50%</option>
                        <option value="Pago Final">Pago Final</option>
                    </select>
                </div>
                <div class="form-group"><label>Monto ($):</label><input type="number" step="0.01" id="pago-monto" required></div>
                <div class="form-group">
                    <label>Método:</label>
                    <select id="pago-metodo" required>
                        <option value="Efectivo">Efectivo</option>
                        <option value="Transferencia">Transferencia</option>
                        <option value="Tarjeta">Tarjeta</option>
                    </select>
                </div>
                <div class="form-group"><label>Referencia:</label><input type="text" id="pago-referencia"></div>
                <div class="form-group"><label>Fecha:</label><input type="date" id="pago-fecha" required></div>
                <button type="submit" class="btn">Registrar Pago</button>
            </form>
        </div>
    </section>
    <?php endif; ?>

    <!-- RECURSOS (RF-08, RF-09) -->
    <?php if ($rol === 'Administrador' || $rol === 'Tecnico'): ?>
    <section id="window-recursos" class="window-content hidden">
        <h2>Disponibilidad y Asignación de Recursos</h2>
        <div class="card" style="padding:1.5rem; margin-bottom:1.5rem;">
            <div class="form-group">
                <label>Consultar disponibilidad por fecha:</label>
                <input type="date" id="disp-fecha">
                <button id="btn-consultar-disponibilidad" class="btn" style="width:auto; margin-top:.5rem;">Consultar</button>
            </div>
            <table class="tabla"><thead><tr><th>Recurso</th><th>Tipo</th><th>Estado</th></tr></thead><tbody id="tabla-disponibilidad-body"></tbody></table>
        </div>

        <div class="card" style="padding:1.5rem;">
            <h3>Asignar Recurso a Evento</h3>
            <form id="form-recurso">
                <div class="form-group">
                    <label>Evento:</label>
                    <select id="rec-evento" required>
                        <option value="">Seleccione...</option>
                        <?php $eventos->data_seek(0); while ($e = $eventos->fetch_assoc()): ?>
                            <option value="<?= $e['id_evento'] ?>" data-fecha="<?= $e['fecha'] ?>">#<?= $e['id_evento'] ?> - <?= htmlspecialchars($e['cliente']) ?> - <?= htmlspecialchars($e['fecha']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Recurso:</label>
                    <select id="rec-recurso" required>
                        <option value="">Seleccione...</option>
                        <?php while ($r = $recursos->fetch_assoc()): ?>
                            <option value="<?= $r['id_recurso'] ?>"><?= htmlspecialchars($r['nombre']) ?> (<?= htmlspecialchars($r['tipo']) ?>)</option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit" class="btn">Asignar Recurso</button>
            </form>
        </div>
    </section>
    <?php endif; ?>

    <!-- HISTORIAL (RF-11) -->
    <section id="window-historial" class="window-content hidden">
        <h2>Historial de Eventos</h2>
        <table class="tabla">
            <thead><tr><th>Evento</th><th>Cliente</th><th>Fecha</th><th>Tipo</th><th>Servicios</th><th>Resultado</th></tr></thead>
            <tbody id="tabla-historial-body"></tbody>
        </table>
    </section>
</div>

<script src="script.js"></script>
</body>
</html>
