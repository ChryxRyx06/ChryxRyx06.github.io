<?php
// ver_contrato.php: vista imprimible del contrato (RF-04)
// Sustituye a la generación con la librería FPDF, que no estaba incluida
// en el proyecto. El usuario puede usar "Imprimir / Guardar como PDF" del navegador.
session_start();
require_once 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    die("Debe iniciar sesión para ver el contrato.");
}

$id_contrato = intval($_GET['id_contrato'] ?? 0);

$query = "SELECT ct.id_contrato, ct.fecha_evento, ct.ubicacion, ct.condiciones,
                 cl.nombre AS cliente, cl.contacto, cl.direccion, cl.datos_fiscales,
                 c.id_cliente, c.monto_total, c.descripcion_tecnica, c.nombre_evento
          FROM contratos ct
          JOIN cotizaciones c ON ct.id_cotizacion = c.id_cotizacion
          JOIN clientes cl ON c.id_cliente = cl.id_cliente
          WHERE ct.id_contrato = ?";

$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_contrato);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    die("Contrato no encontrado.");
}

// El cliente solo puede ver sus propios contratos
if (($_SESSION['rol'] ?? '') === 'Cliente' && intval($row['id_cliente']) !== intval($_SESSION['id_cliente'] ?? 0)) {
    die("No tiene permiso para ver este contrato.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Contrato #<?= $row['id_contrato'] ?> - SGCEA</title>
<link rel="stylesheet" href="Styles.css">
<style>
  .contrato { max-width: 800px; margin: 2rem auto; background:#fff; padding:2rem; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.1); }
  .firmas { display:flex; justify-content:space-around; margin-top:4rem; text-align:center; }
  .firmas div { border-top:1px solid #333; padding-top:.5rem; width:200px; }
  @media print { .no-print { display:none; } }
</style>
</head>
<body>
<div class="contrato">
    <h2 style="text-align:center;">QUINTO CANAL DE EVENTOS</h2>
    <h3 style="text-align:center;">Contrato de Prestación de Servicios Audiovisuales</h3>
    <p><strong>Contrato:</strong> #<?= $row['id_contrato'] ?></p>
    <p><strong>Cliente:</strong> <?= htmlspecialchars($row['cliente']) ?></p>
    <p><strong>RFC / Datos fiscales:</strong> <?= htmlspecialchars($row['datos_fiscales']) ?></p>
    <p><strong>Evento:</strong> <?= htmlspecialchars($row['nombre_evento']) ?></p>
    <p><strong>Ubicación:</strong> <?= htmlspecialchars($row['ubicacion']) ?></p>
    <p><strong>Fecha del evento:</strong> <?= htmlspecialchars($row['fecha_evento']) ?></p>

    <h4>Detalle del servicio</h4>
    <p><?= nl2br(htmlspecialchars($row['descripcion_tecnica'])) ?></p>
    <p><strong>Monto total:</strong> $<?= number_format($row['monto_total'], 2) ?> MXN</p>

    <h4>Cláusulas y condiciones</h4>
    <p><?= nl2br(htmlspecialchars($row['condiciones'])) ?></p>
    <p>1. Se requiere un anticipo mínimo del 50% para la confirmación del evento.<br>
       2. El equipo y personal técnico están sujetos a validación de disponibilidad.</p>

    <div class="firmas">
        <div>Firma de la Empresa</div>
        <div>Firma del Cliente</div>
    </div>

    <div class="no-print" style="text-align:center; margin-top:2rem;">
        <button class="btn" style="width:auto; padding:.6rem 1.5rem;" onclick="window.print()">Imprimir / Guardar como PDF</button>
    </div>
</div>
</body>
</html>
