<?php
// generar_contrato.php (RF-04): genera el contrato y el evento a partir de una cotización Aprobada
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (($_SESSION['rol'] ?? '') !== 'Administrador') {
    echo json_encode(["success" => false, "message" => "Solo el administrador puede generar contratos."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id_cotizacion = $data['id_cotizacion'] ?? null;
$fecha_evento = $data['fecha_evento'] ?? '';
$ubicacion = trim($data['ubicacion'] ?? '');
$condiciones = trim($data['condiciones'] ?? '');

if (!$id_cotizacion || empty($fecha_evento) || empty($ubicacion) || empty($condiciones)) {
    echo json_encode(["success" => false, "message" => "Complete los campos obligatorios del contrato."]);
    exit;
}

// Verificar que la cotización esté Aprobada
$stmt = $conexion->prepare("SELECT estado FROM cotizaciones WHERE id_cotizacion = ?");
$stmt->bind_param("i", $id_cotizacion);
$stmt->execute();
$cot = $stmt->get_result()->fetch_assoc();

if (!$cot || $cot['estado'] !== 'Aprobada') {
    echo json_encode(["success" => false, "message" => "Solo se pueden generar contratos a partir de cotizaciones Aprobadas."]);
    exit;
}

// Evitar duplicar un contrato ya existente para la misma cotización
$stmt_chk = $conexion->prepare("SELECT id_contrato FROM contratos WHERE id_cotizacion = ?");
$stmt_chk->bind_param("i", $id_cotizacion);
$stmt_chk->execute();
if ($stmt_chk->get_result()->fetch_assoc()) {
    echo json_encode(["success" => false, "message" => "Esta cotización ya tiene un contrato generado."]);
    exit;
}

$conexion->begin_transaction();

try {
    // Insertar Contrato
    $stmt_c = $conexion->prepare("INSERT INTO contratos (id_cotizacion, fecha_evento, ubicacion, condiciones, estatus) VALUES (?, ?, ?, ?, 'Activo')");
    $stmt_c->bind_param("isss", $id_cotizacion, $fecha_evento, $ubicacion, $condiciones);
    $stmt_c->execute();
    $id_contrato = $stmt_c->insert_id;

    // Generar automáticamente el Evento en estado Programado
    $stmt_e = $conexion->prepare("INSERT INTO eventos (id_contrato, fecha, horario, ubicacion, tipo_evento, estado) VALUES (?, ?, '12:00:00', ?, 'Privado', 'Programado')");
    $stmt_e->bind_param("iss", $id_contrato, $fecha_evento, $ubicacion);
    $stmt_e->execute();

    $conexion->commit();
    echo json_encode(["success" => true, "message" => "Contrato y Evento en estado Programado generados correctamente.", "id_contrato" => $id_contrato]);
} catch (Exception $e) {
    $conexion->rollback();
    echo json_encode(["success" => false, "message" => "Error al generar contrato: " . $e->getMessage()]);
}
?>
