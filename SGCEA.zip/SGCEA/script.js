document.addEventListener('DOMContentLoaded', () => {
    const windows = document.querySelectorAll('.window-content');
    const navButtons = document.querySelectorAll('.nav-btn');

    // Notificaciones (verde=éxito, rojo=error, amarillo=alerta)
    function showAlert(mensaje, tipo) {
        let tipoNoti = 'alerta';
        if (tipo === 'success' || tipo === 'exito') tipoNoti = 'exito';
        else if (tipo === 'danger' || tipo === 'error') tipoNoti = 'error';

        let box = document.getElementById('notificacion-box');
        if (!box) {
            box = document.createElement('div');
            box.id = 'notificacion-box';
            document.body.appendChild(box);
        }
        box.className = `notificacion-badge noti-${tipoNoti}`;
        box.innerText = mensaje;
        box.style.display = 'block';
        setTimeout(() => { box.style.display = 'none'; }, 4000);
    }

    async function postJSON(url, data) {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return response.json();
    }

    // Navegación entre ventanas del panel
    function switchWindow(targetWindowId) {
        windows.forEach(win => win.classList.toggle('hidden', win.id !== targetWindowId));
        navButtons.forEach(btn => btn.classList.toggle('active', btn.getAttribute('data-target') === targetWindowId));

        if (targetWindowId === 'window-cotizaciones') cargarCotizaciones();
        if (targetWindowId === 'window-historial') cargarHistorial();
    }

    navButtons.forEach(btn => {
        btn.addEventListener('click', () => switchWindow(btn.getAttribute('data-target')));
    });

    // Mostrar la primera pestaña disponible al cargar el panel
    if (navButtons.length > 0) {
        switchWindow(navButtons[0].getAttribute('data-target'));
    }

    // ---------------------------------------------------------------
    // CLIENTES (RF-01)
    // ---------------------------------------------------------------
    const formCliente = document.getElementById('form-cliente');
    if (formCliente) {
        formCliente.addEventListener('submit', async (e) => {
            e.preventDefault();
            const data = {
                nombre: document.getElementById('cli-nombre').value,
                contacto: document.getElementById('cli-contacto').value,
                direccion: document.getElementById('cli-direccion').value,
                datos_fiscales: document.getElementById('cli-fiscales').value
            };
            try {
                const result = await postJSON('guardar_cliente.php', data);
                showAlert(result.message, result.success ? 'success' : 'danger');
                if (result.success) formCliente.reset();
            } catch (err) {
                showAlert('Error al conectar con el servidor.', 'danger');
            }
        });
    }

    // ---------------------------------------------------------------
    // COTIZACIONES (RF-02, RF-03)
    // ---------------------------------------------------------------
    const formCotizacion = document.getElementById('form-cotizacion');
    if (formCotizacion) {
        formCotizacion.addEventListener('submit', async (e) => {
            e.preventDefault();

            const servicios = Array.from(document.querySelectorAll('input[name="servicio"]:checked')).map(cb => cb.value);
            if (servicios.length === 0) {
                showAlert('Debe seleccionar al menos un servicio audiovisual.', 'danger');
                return;
            }

            const data = {
                id_cliente: document.getElementById('cot-cliente').value,
                nombre_evento: document.getElementById('cot-evento').value,
                descripcion: document.getElementById('cot-desc').value,
                servicios: servicios,
                monto: parseFloat(document.getElementById('cot-monto').value),
                vigencia: document.getElementById('cot-vigencia').value
            };

            try {
                const result = await postJSON('guardar_cotizacion.php', data);
                showAlert(result.message, result.success ? 'success' : 'danger');
                if (result.success) {
                    formCotizacion.reset();
                    cargarCotizaciones();
                }
            } catch (err) {
                showAlert('Error al conectar con el servidor.', 'danger');
            }
        });
    }

    async function cargarCotizaciones() {
        const tbody = document.getElementById('tabla-cotizaciones-body');
        if (!tbody) return;
        const esCliente = document.getElementById('cot-cliente') === null; // no existe el select -> vista de cliente

        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando...</td></tr>';
        try {
            const data = await (await fetch('obtener_cotizaciones.php')).json();
            const cotizaciones = data.cotizaciones || [];

            if (cotizaciones.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay cotizaciones registradas.</td></tr>';
                return;
            }

            tbody.innerHTML = '';
            cotizaciones.forEach(cot => {
                const tr = document.createElement('tr');
                let acciones = '';
                if (esCliente && cot.estado === 'Pendiente') {
                    acciones = `<td>
                        <button class="btn-sm btn-aprobar" data-id="${cot.id_cotizacion}">Aprobar</button>
                        <button class="btn-sm btn-rechazar" data-id="${cot.id_cotizacion}">Rechazar</button>
                    </td>`;
                } else if (esCliente) {
                    acciones = '<td>-</td>';
                }
                tr.innerHTML = `
                    <td>${cot.id_cotizacion}</td>
                    <td>${cot.cliente}</td>
                    <td>${cot.evento || ''}</td>
                    <td>${cot.servicios || ''}</td>
                    <td>$${parseFloat(cot.monto_total).toFixed(2)}</td>
                    <td>${cot.vigencia}</td>
                    <td><span class="badge badge-${cot.estado.toLowerCase()}">${cot.estado}</span></td>
                    ${acciones}
                `;
                tbody.appendChild(tr);
            });

            tbody.querySelectorAll('.btn-aprobar, .btn-rechazar').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const accion = btn.classList.contains('btn-aprobar') ? 'Aprobar' : 'Rechazar';
                    const result = await postJSON('aprobar_rechazar_cotizacion.php', { id_cotizacion: btn.dataset.id, accion });
                    showAlert(result.message, result.success ? 'success' : 'danger');
                    if (result.success) cargarCotizaciones();
                });
            });
        } catch (err) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:red;">Error al consultar la base de datos.</td></tr>';
        }
    }

    // ---------------------------------------------------------------
    // CONTRATOS (RF-04)
    // ---------------------------------------------------------------
    const formContrato = document.getElementById('form-contrato');
    if (formContrato) {
        formContrato.addEventListener('submit', async (e) => {
            e.preventDefault();
            const data = {
                id_cotizacion: document.getElementById('con-cotizacion').value,
                fecha_evento: document.getElementById('con-fecha').value,
                ubicacion: document.getElementById('con-ubicacion').value,
                condiciones: document.getElementById('con-condiciones').value
            };
            const result = await postJSON('generar_contrato.php', data);
            showAlert(result.message, result.success ? 'success' : 'danger');
            if (result.success) {
                formContrato.reset();
                if (result.id_contrato) window.open('ver_contrato.php?id_contrato=' + result.id_contrato, '_blank');
            }
        });
    }

    // ---------------------------------------------------------------
    // EVENTOS (RF-05, RF-06, RF-11)
    // ---------------------------------------------------------------
    document.querySelectorAll('.btn-confirmar').forEach(btn => {
        btn.addEventListener('click', async () => {
            const result = await postJSON('confirmar_evento.php', { id_evento: btn.dataset.id });
            showAlert(result.message, result.success ? 'success' : 'danger');
            if (result.success) location.reload();
        });
    });

    document.querySelectorAll('.btn-finalizar').forEach(btn => {
        btn.addEventListener('click', async () => {
            const result = await postJSON('finalizar_evento.php', { id_evento: btn.dataset.id });
            showAlert(result.message, result.success ? 'success' : 'danger');
            if (result.success) location.reload();
        });
    });

    // ---------------------------------------------------------------
    // PAGOS (RF-07)
    // ---------------------------------------------------------------
    const formPago = document.getElementById('form-pago');
    if (formPago) {
        formPago.addEventListener('submit', async (e) => {
            e.preventDefault();
            const data = {
                id_evento: document.getElementById('pago-evento').value,
                tipo: document.getElementById('pago-tipo').value,
                monto: parseFloat(document.getElementById('pago-monto').value),
                metodo: document.getElementById('pago-metodo').value,
                referencia: document.getElementById('pago-referencia').value,
                fecha: document.getElementById('pago-fecha').value
            };
            const result = await postJSON('registrar_pago.php', data);
            showAlert(result.message, result.success ? 'success' : 'danger');
            if (result.success) formPago.reset();
        });
    }

    // ---------------------------------------------------------------
    // RECURSOS Y DISPONIBILIDAD (RF-08, RF-09)
    // ---------------------------------------------------------------
    const btnDisponibilidad = document.getElementById('btn-consultar-disponibilidad');
    if (btnDisponibilidad) {
        btnDisponibilidad.addEventListener('click', async () => {
            const fecha = document.getElementById('disp-fecha').value;
            const tbody = document.getElementById('tabla-disponibilidad-body');
            if (!fecha) { showAlert('Seleccione una fecha.', 'danger'); return; }

            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;">Consultando...</td></tr>';
            const data = await (await fetch('validar_disponibilidad.php?fecha=' + encodeURIComponent(fecha))).json();
            const recursos = data.recursos || [];

            tbody.innerHTML = '';
            recursos.forEach(r => {
                const tr = document.createElement('tr');
                const claseEstado = r.estado_disponibilidad === 'Disponible' ? 'badge-aprobada' : 'badge-rechazada';
                tr.innerHTML = `<td>${r.nombre}</td><td>${r.tipo}</td><td><span class="badge ${claseEstado}">${r.estado_disponibilidad}</span></td>`;
                tbody.appendChild(tr);
            });
        });
    }

    const formRecurso = document.getElementById('form-recurso');
    if (formRecurso) {
        formRecurso.addEventListener('submit', async (e) => {
            e.preventDefault();
            const eventoSelect = document.getElementById('rec-evento');
            const fecha = eventoSelect.options[eventoSelect.selectedIndex]?.dataset.fecha;
            const data = {
                id_evento: eventoSelect.value,
                id_recurso: document.getElementById('rec-recurso').value,
                fecha: fecha
            };
            const result = await postJSON('asignar_recurso.php', data);
            showAlert(result.message, result.success ? 'success' : 'danger');
            if (result.success) formRecurso.reset();
        });
    }

    // ---------------------------------------------------------------
    // HISTORIAL (RF-11)
    // ---------------------------------------------------------------
    async function cargarHistorial() {
        const tbody = document.getElementById('tabla-historial-body');
        if (!tbody) return;
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Cargando...</td></tr>';
        try {
            const data = await (await fetch('obtener_historial.php')).json();
            const historial = data.historial || [];
            if (historial.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Aún no hay eventos finalizados.</td></tr>';
                return;
            }
            tbody.innerHTML = '';
            historial.forEach(h => {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td>#${h.id_evento}</td><td>${h.cliente}</td><td>${h.fecha}</td><td>${h.tipo_evento}</td><td>${h.servicios_brindados}</td><td>${h.resultado}</td>`;
                tbody.appendChild(tr);
            });
        } catch (err) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:red;">Error al consultar el historial.</td></tr>';
        }
    }
});
