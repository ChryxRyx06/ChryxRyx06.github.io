<?php
// guardar_cotizacion.php (RF-02)
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (($_SESSION['rol'] ?? '') !== 'Administrador') {
    echo json_encode(["success" => false, "message" => "Solo el administrador puede crear cotizaciones."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$id_cliente = intval($data['id_cliente'] ?? 0);
$nombre_evento = trim($data['nombre_evento'] ?? '');
$descripcion_tecnica = trim($data['descripcion'] ?? '');
$servicios = $data['servicios'] ?? [];
$monto_total = floatval($data['monto'] ?? 0);
$vigencia = $data['vigencia'] ?? '';

if (!$id_cliente || empty($nombre_evento) || empty($descripcion_tecnica) || empty($servicios) || $monto_total <= 0 || empty($vigencia)) {
    echo json_encode([
        "status" => "error",
        "success" => false,
        "message" => "Todos los campos de la cotización son obligatorios y debe seleccionar al menos un servicio."
    ]);
    exit;
}

$conexion->begin_transaction();

try {
    $stmt = $conexion->prepare("INSERT INTO cotizaciones (id_cliente, nombre_evento, descripcion_tecnica, monto_total, vigencia, estado) VALUES (?, ?, ?, ?, ?, 'Pendiente')");
    $stmt->bind_param("issds", $id_cliente, $nombre_evento, $descripcion_tecnica, $monto_total, $vigencia);
    $stmt->execute();
    $id_cotizacion = $stmt->insert_id;

    $stmt_srv = $conexion->prepare("INSERT INTO cotizacion_servicios (id_cotizacion, servicio) VALUES (?, ?)");
    foreach ($servicios as $srv) {
        $stmt_srv->bind_param("is", $id_cotizacion, $srv);
        $stmt_srv->execute();
    }

    $conexion->commit();
    echo json_encode(["success" => true, "message" => "Cotización registrada en estado Pendiente."]);
} catch (Exception $e) {
    $conexion->rollback();
    echo json_encode(["success" => false, "message" => "Error al guardar la cotización: " . $e->getMessage()]);
}
?>
