<?php
// conexion.php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "sgcea_db";

$conexion = new mysqli($host, $user, $pass, $dbname);

if ($conexion->connect_error) {
    header('Content-Type: application/json');
    die(json_encode(["status" => "error", "success" => false, "message" => "Error de conexión: " . $conexion->connect_error]));
}

$conexion->set_charset("utf8mb4");
?>
