<?php
// aprobar_rechazar_cotizacion.php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (($_SESSION['rol'] ?? '') !== 'Cliente') {
    echo json_encode(["success" => false, "message" => "Solo el cliente puede aprobar o rechazar su cotización."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id_cotizacion = $data['id_cotizacion'] ?? null;
$accion = $data['accion'] ?? ''; // 'Aprobar' o 'Rechazar'

if (!$id_cotizacion || !in_array($accion, ['Aprobar', 'Rechazar'])) {
    echo json_encode(["success" => false, "message" => "Acción o cotización no válida."]);
    exit;
}

// Consultar vigencia, estado actual y verificar que la cotización pertenezca al cliente en sesión
$stmt = $conexion->prepare("SELECT vigencia, estado, id_cliente FROM cotizaciones WHERE id_cotizacion = ?");
$stmt->bind_param("i", $id_cotizacion);
$stmt->execute();
$cot = $stmt->get_result()->fetch_assoc();

if (!$cot) {
    echo json_encode(["success" => false, "message" => "La cotización no existe."]);
    exit;
}

if (intval($cot['id_cliente']) !== intval($_SESSION['id_cliente'] ?? 0)) {
    echo json_encode(["success" => false, "message" => "Esta cotización no pertenece a su cuenta."]);
    exit;
}

if ($cot['estado'] !== 'Pendiente') {
    echo json_encode(["success" => false, "message" => "Esta cotización ya ha sido procesada."]);
    exit;
}

if (strtotime($cot['vigencia']) < strtotime(date('Y-m-d'))) {
    // Actualizar estado a Vencida
    $update = $conexion->prepare("UPDATE cotizaciones SET estado = 'Vencida' WHERE id_cotizacion = ?");
    $update->bind_param("i", $id_cotizacion);
    $update->execute();
    echo json_encode(["success" => false, "message" => "La cotización ha vencido y no puede ser aprobada."]);
    exit;
}

$nuevo_estado = ($accion === 'Aprobar') ? 'Aprobada' : 'Rechazada';
$update = $conexion->prepare("UPDATE cotizaciones SET estado = ? WHERE id_cotizacion = ?");
$update->bind_param("si", $nuevo_estado, $id_cotizacion);

if ($update->execute()) {
    echo json_encode(["success" => true, "message" => "Cotización marcada como " . strtolower($nuevo_estado) . "."]);
} else {
    echo json_encode(["success" => false, "message" => "Error al actualizar estado."]);
}
?>