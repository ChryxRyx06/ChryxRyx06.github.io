<?php
// obtener_cotizaciones.php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(["success" => false, "message" => "Debe iniciar sesión."]);
    exit;
}

$rol = $_SESSION['rol'] ?? 'Administrador';
$id_cliente = $_SESSION['id_cliente'] ?? null;

$sql = "SELECT c.id_cotizacion, c.id_cliente, cl.nombre AS cliente, c.nombre_evento AS evento,
               c.descripcion_tecnica, c.monto_total, c.vigencia, c.estado,
               GROUP_CONCAT(cs.servicio SEPARATOR ', ') AS servicios
        FROM cotizaciones c
        JOIN clientes cl ON c.id_cliente = cl.id_cliente
        LEFT JOIN cotizacion_servicios cs ON c.id_cotizacion = cs.id_cotizacion";

if ($rol === 'Cliente' && $id_cliente) {
    $sql .= " WHERE c.id_cliente = " . intval($id_cliente);
}

$sql .= " GROUP BY c.id_cotizacion ORDER BY c.id_cotizacion DESC";

$result = $conexion->query($sql);
$cotizaciones = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $cotizaciones[] = $row;
    }
}

echo json_encode(["success" => true, "cotizaciones" => $cotizaciones]);
?>
