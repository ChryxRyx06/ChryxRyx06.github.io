<?php
session_start();
require_once "conexion.php";

$error = "";

// Si ya hay sesión activa, redirigir al panel principal
if (isset($_SESSION['id_usuario'])) {
    header("Location: panel.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre         = trim($_POST['nombre'] ?? '');
    $contacto       = trim($_POST['contacto'] ?? '');
    $direccion      = trim($_POST['direccion'] ?? '');
    $datos_fiscales = trim($_POST['datos_fiscales'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $password       = $_POST['password'] ?? '';
    $password2      = $_POST['password2'] ?? '';

    if (empty($nombre) || empty($contacto) || empty($direccion) || empty($datos_fiscales) || empty($email) || empty($password) || empty($password2)) {
        $error = "Por favor completa todos los campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "El correo electrónico no es válido.";
    } elseif (strlen($password) < 6) {
        $error = "La contraseña debe tener al menos 6 caracteres.";
    } elseif ($password !== $password2) {
        $error = "Las contraseñas no coinciden.";
    } else {
        // Verificar que el correo no esté registrado ya
        $stmt = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Ya existe una cuenta registrada con ese correo electrónico.";
            $stmt->close();
        } else {
            $stmt->close();

            $conexion->begin_transaction();
            try {
                // 1) Crear el registro del cliente (RD-01)
                $stmtCliente = $conexion->prepare("INSERT INTO clientes (nombre, contacto, direccion, datos_fiscales) VALUES (?, ?, ?, ?)");
                $stmtCliente->bind_param("ssss", $nombre, $contacto, $direccion, $datos_fiscales);
                $stmtCliente->execute();
                $id_cliente = $conexion->insert_id;
                $stmtCliente->close();

                // 2) Crear el usuario con rol Cliente, contraseña protegida con hash
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $rol = 'Cliente';
                $stmtUsuario = $conexion->prepare("INSERT INTO usuarios (nombre, email, password, rol, id_cliente) VALUES (?, ?, ?, ?, ?)");
                $stmtUsuario->bind_param("ssssi", $nombre, $email, $passwordHash, $rol, $id_cliente);
                $stmtUsuario->execute();
                $id_usuario = $conexion->insert_id;
                $stmtUsuario->close();

                $conexion->commit();

                // Iniciar sesión automáticamente tras el registro
                $_SESSION['id_usuario'] = $id_usuario;
                $_SESSION['nombre'] = $nombre;
                $_SESSION['rol'] = $rol;
                $_SESSION['id_cliente'] = $id_cliente;

                header("Location: panel.php");
                exit;
            } catch (Exception $e) {
                $conexion->rollback();
                $error = "No se pudo completar el registro. Intenta nuevamente.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuenta - SGCEA</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

<header>
    <a href="index.html" class="logo">Quinto Canal de Eventos</a>
    <nav>
        <a href="index.html">Inicio</a>
        <a href="login.php" class="btn-nav">Iniciar Sesión</a>
    </nav>
</header>

<div class="auth-box" style="max-width: 480px;">
    <h2>Crear Cuenta de Cliente</h2>
    <p style="text-align:center; margin-bottom:1.5rem; color:#555;">Regístrate para solicitar cotizaciones, dar seguimiento a tus eventos y consultar tus contratos.</p>

    <?php if (!empty($error)): ?>
        <div class="alert-danger" style="text-align: center;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="registro.php">
        <div class="form-group">
            <label for="nombre">Nombre o Razón Social:</label>
            <input type="text" id="nombre" name="nombre" required placeholder="Nombre completo o empresa" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="contacto">Teléfono de Contacto:</label>
            <input type="text" id="contacto" name="contacto" required placeholder="272-123-4567" value="<?= htmlspecialchars($_POST['contacto'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" required placeholder="Calle, número, ciudad" value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="datos_fiscales">Datos Fiscales (RFC):</label>
            <input type="text" id="datos_fiscales" name="datos_fiscales" required placeholder="RFC o datos fiscales" value="<?= htmlspecialchars($_POST['datos_fiscales'] ?? '') ?>">
        </div>

        <hr style="margin: 1.5rem 0;">

        <div class="form-group">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required placeholder="tucorreo@ejemplo.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required placeholder="Mínimo 6 caracteres">
        </div>

        <div class="form-group">
            <label for="password2">Confirmar Contraseña:</label>
            <input type="password" id="password2" name="password2" required placeholder="Repite tu contraseña">
        </div>

        <button type="submit" class="btn">Crear Cuenta</button>
    </form>

    <p style="text-align:center; margin-top:1rem;">
        ¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a>
    </p>
</div>

</body>
</html>
