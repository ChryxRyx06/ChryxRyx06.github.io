<?php
// registrar_pago.php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

if (($_SESSION['rol'] ?? '') !== 'Administrador') {
    echo json_encode(["success" => false, "message" => "Solo el administrador puede registrar pagos."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id_evento = $data['id_evento'] ?? null;
$monto = floatval($data['monto'] ?? 0);
$tipo = $data['tipo'] ?? ''; // 'Anticipo 50%' o 'Pago Final'
$metodo = $data['metodo'] ?? ''; // 'Efectivo', 'Transferencia', 'Tarjeta'
$referencia = trim($data['referencia'] ?? '');
$fecha = $data['fecha'] ?? date('Y-m-d');

if (!$id_evento || $monto <= 0 || empty($tipo) || empty($metodo)) {
    echo json_encode(["success" => false, "message" => "Ingrese un monto y datos de pago válidos."]);
    exit;
}

// Validar que el pago no supere el monto total del servicio
$stmt_m = $conexion->prepare("SELECT c.monto_total 
                              FROM eventos e 
                              JOIN contratos ct ON e.id_contrato = ct.id_contrato 
                              JOIN cotizaciones c ON ct.id_cotizacion = c.id_cotizacion 
                              WHERE e.id_evento = ?");
$stmt_m->bind_param("i", $id_evento);
$stmt_m->execute();
$res_m = $stmt_m->get_result()->fetch_assoc();

if ($res_m && $monto > floatval($res_m['monto_total'])) {
    echo json_encode(["success" => false, "message" => "El monto ingresado no puede ser mayor al total del servicio."]);
    exit;
}

$stmt = $conexion->prepare("INSERT INTO pagos (id_evento, monto, tipo, metodo, referencia, fecha, estatus) VALUES (?, ?, ?, ?, ?, ?, 'Pagado')");
$stmt->bind_param("idssss", $id_evento, $monto, $tipo, $metodo, $referencia, $fecha);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Pago registrado correctamente."]);
} else {
    echo json_encode(["success" => false, "message" => "Error al registrar el pago: " . $conexion->error]);
}
?>